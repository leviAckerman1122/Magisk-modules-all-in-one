SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

print_modname() {
ui_print ""
ui_print "╭━━━┳━━━┳━╮╭━┳━╮╭━╮"
ui_print "┃╭━╮┃╭━━┻╮╰╯╭┻╮╰╯╭╯"
ui_print "┃╰━╯┃╰━━╮╰╮╭╯╱╰╮╭╯"
ui_print "┃╭╮╭┫╭━━╯╭╯╰╮╱╭╯╰╮"
ui_print "┃┃┃╰┫╰━━┳╯╭╮╰┳╯╭╮╰╮"
ui_print "╰╯╰━┻━━━┻━╯╰━┻━╯╰━╯"
ui_print "╭━╮╭━╮"
ui_print "╰╮╰╯╭╯"
ui_print "╱╰╮╭╯"
ui_print "╱╭╯╰╮"
ui_print "╭╯╭╮╰╮"
ui_print "╰━╯╰━╯"
ui_print "╭━━━┳━━━┳━━━┳━━━┳━╮╱╭┳━━━┳━━╮"
ui_print "┃╭━╮┃╭━╮┃╭━╮┃╭━━┫┃╰╮┃┃╭━╮┣┫┣╯"
ui_print "┃┃╱┃┃╰━╯┃╰━━┫╰━━┫╭╮╰╯┃╰━━╮┃┃"
ui_print "┃┃╱┃┃╭━━┻━━╮┃╭━━┫┃╰╮┃┣━━╮┃┃┃"
ui_print "┃╰━╯┃┃╱╱┃╰━╯┃╰━━┫┃╱┃┃┃╰━╯┣┫┣╮"
ui_print "╰━━━┻╯╱╱╰━━━┻━━━┻╯╱╰━┻━━━┻━━╯"
ui_print ""
ui_print " 🔹VERSION : 3.3 BOS"
ui_print " 🔹CODENAME : LiteMenu"
ui_print " 🔹BUILD DATE : 18.03.2024 - 24.03.2024"
ui_print ""
ui_print " 🔹INFO OPSENSI : BOS TIER × LITEMENU"
ui_print ""
}

on_install() {
  ui_print " 💠 Preparing Installation..."
  sleep 1
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print ""
# Cek apakah package Free Fire atau Free Fire Max ada di device
if pm list packages | grep -q "com.dts.freefireth"; then
    echo " ✅ Package Free Fire ditemukan"   echo " Mengoptimalisasi Free Fire..."
    device_config put game_overlay com.dts.freefireth mode=2,fps=120
dumpsys deviceidle whitelist +com.dts.freefireth
appops set com.dts.freefireth RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.dts.freefireth
cmd package compile -m speed --secondary-dex -f com.dts.freefireth
cmd package compile -r first-boot -f com.dts.freefireth
cmd package compile -m speed --check-prof false -f com.dts.freefireth
elif pm list packages | grep -q "com.dts.freefiremax"; then
    echo " ✅ Package Free Fire Max ditemukan"
    echo "Mengoptimalisasi Free Fire Max..."
    # Jalankan perintah untuk Free Fire Max
    device_config put game_overlay com.dts.freefiremax mode=2,fps=120
    dumpsys deviceidle whitelist +com.dts.freefiremax
    appops set com.dts.freefiremax RUN_IN_BACKGROUND allow
    cmd package compile -m everything-profile -f com.dts.freefiremax
    cmd package compile -m speed --secondary-dex -f com.dts.freefiremax
    cmd package compile -r first-boot -f com.dts.freefiremax
    cmd package compile -m speed --check-prof false -f com.dts.freefiremax
else
    echo " ❎ Free Fire/Free Fire Max tidak ditemukan."
fi
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'size' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'den' -d $MODPATH >&2
  ui_print ""
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/* 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin/opsensi" 0 0 0755 0755
}
su -c 'am start -a android.intent.action.VIEW -d https://t.me/levi2341 > /dev/null'
