#!/system/bin/sh
MODDIR=${0%/*}
# Credits by ZYAREXX
# Peraturan Salin Kode:
# Jika Anda ingin menggunakan atau membagikan kode ini, mohon berikan Credits kepada pembuat asli.

# Menentukan package name dari Free Fire dan Free Fire Max
FREE_FIRE_PKG="com.dts.freefireth"
FREE_FIRE_MAX_PKG="com.dts.freefiremax"

# Fungsi untuk mengatur wm size dan wm density
set_custom_wm() {
    CUSTOM_WM_SIZE=$(cat /data/adb/modules/REXXXOPSENSI/size)
    CUSTOM_WM_DENSITY=$(cat /data/adb/modules/REXXXOPSENSI/den)
    wm size $CUSTOM_WM_SIZE
    wm density $CUSTOM_WM_DENSITY
}

# Fungsi untuk mereset wm size dan wm density ke default
reset_wm() {
    wm size reset
    wm density reset
}

# Loop untuk memeriksa aplikasi yang sedang aktif
while true; do
    CURRENT_APP=$(dumpsys window | grep -E 'mCurrentFocus|mFocusedApp')

    # Jika Free Fire atau Free Fire Max terdeteksi
    if [[ "$CURRENT_APP" == *"$FREE_FIRE_PKG"* ]] || [[ "$CURRENT_APP" == *"$FREE_FIRE_MAX_PKG"* ]]; then
        # Memeriksa apakah terjadi perubahan pada file size atau den
        NEW_WM_SIZE=$(cat /data/adb/modules/REXXXOPSENSI/size)
        NEW_WM_DENSITY=$(cat /data/adb/modules/REXXXOPSENSI/den)
        # Selalu mengatur ulang wm size dan wm density setiap kali Free Fire dibuka
        set_custom_wm
    else
        reset_wm
    fi

    # Tunggu selama 5 detik sebelum memeriksa lagi
    sleep 5
done
